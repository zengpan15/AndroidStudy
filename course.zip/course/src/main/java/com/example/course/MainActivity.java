package com.example.course;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.course.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initView();
        checkRemember();
    }

    private void initView() {
        binding.btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = binding.etUsername.getText().toString();
                String age = binding.etAge.getText().toString();

                if (!TextUtils.isEmpty(username) && !TextUtils.isEmpty(age)) {
                    if (binding.cbRemember.isChecked()) {
                        remember(username, age);
                    } else {
                        clear();
                    }
                    Toast.makeText(MainActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "姓名或年龄不能为空", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void remember(String username, String age) {
        SharedPreferences sp = getSharedPreferences("user", MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        edit.putString("username", username);
        edit.putString("age", age);
        edit.apply();

//        sp.edit().putString("username", username)
//                .putString("password", password)
//                .apply();
    }

    private void checkRemember() {
        SharedPreferences sp = getSharedPreferences("user", MODE_PRIVATE);
        binding.etUsername.setText(sp.getString("username", ""));
        binding.etAge.setText(sp.getString("age", ""));
    }

    private void clear() {
        SharedPreferences sp = getSharedPreferences("user", MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        // edit.remove("username");
        edit.clear();
        edit.apply();

        // sp.edit().clear().apply();
    }


}